﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Todo_WebAPI.Models
{
    public class TodoContext
    {
        public string ConnectionString { get; set; }

        public TodoContext(string connectionString)
        {
            this.ConnectionString = connectionString;
        }

        private MySqlConnection GetConnection()
        {
            return new MySqlConnection(ConnectionString);
        }

        public List<TodoItem> GetAllTodo()
        {
            List<TodoItem> list = new List<TodoItem>();

            using (MySqlConnection conn = GetConnection())
            {
                conn.Open();
                MySqlCommand cmd = new MySqlCommand("SELECT * FROM todo", conn);
                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        list.Add(new TodoItem()
                        {
                            id = reader.GetInt32("id"),
                            title = reader.GetString("title"),
                            time = reader.GetString("time"),
                            persent = reader.GetString("persent"),
                            description = reader.GetString("description")
                        });
                    }
                }
            }
            return list;
        }

        public List<TodoItem> GetTodo(string id)
        {
            List<TodoItem> list = new List<TodoItem>();

            using (MySqlConnection conn = GetConnection())
            {
                conn.Open();
                MySqlCommand cmd = new MySqlCommand("SELECT * FROM todo WHERE id = @id", conn);
                cmd.Parameters.AddWithValue("@id", id);

                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        list.Add(new TodoItem()
                        {
                            id = reader.GetInt32("id"),
                            title = reader.GetString("title"),
                            time = reader.GetString("time"),
                            persent = reader.GetString("persent"),
                            description = reader.GetString("description")
                        });
                    }
                }
            }
            return list;
        }
    }
}