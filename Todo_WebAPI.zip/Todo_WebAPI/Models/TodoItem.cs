﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Todo_WebAPI.Models
{
    public class TodoItem
    {
        private TodoContext Context;

        public int id { get; set; }
        public string title { get; set; }
        public string time { get; set; }
        public string persent { get; set; }
        public string description { get; set; }
    }
}