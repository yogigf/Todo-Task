﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Todo_WebAPI.Models;

namespace Todo_WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TodoController : ControllerBase
    {
        private TodoContext _context;

        public TodoController(TodoContext context)
        {
            this._context = context;
        }

        // GET: api/User
        [HttpGet]
        public ActionResult<IEnumerable<TodoItem>> GetTodoItems()
        {
            _context = HttpContext.RequestServices.GetService(typeof(TodoContext)) as TodoContext;
            //return new string[] { "value1", "value2" };
            return _context.GetAllTodo();
        }

        //Get : api/user/{id}
        [HttpGet("{id}", Name = "Get")]
        public ActionResult<IEnumerable<TodoItem>> GetTodoItem(String id)
        {
            _context = HttpContext.RequestServices.GetService(typeof(TodoContext)) as TodoContext;
            return _context.GetTodo(id);
        }
    }
}